import 'package:flutter/material.dart';
import 'package:flutter_practica_0/src/app.dart'; 

void main() {
  runApp(MyApp());
}
